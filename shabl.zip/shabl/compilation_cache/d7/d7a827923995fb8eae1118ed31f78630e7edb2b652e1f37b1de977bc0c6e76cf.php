<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Buklet.html */
class __TwigTemplate_cfd80d5f9cc8c02d4eeab10a59f88f5077f54b9db76fe9fc6c9e61757086f1b4 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'text' => [$this, 'block_text'],
            'form' => [$this, 'block_form'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Feedback.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("Feedback.html", "Buklet.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"Feedback.css\">
    <link rel=\"stylesheet\" href=\"Buklet.css\">
";
    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        echo "Буклеты";
    }

    // line 8
    public function block_sectioninf($context, array $blocks = [])
    {
    }

    // line 10
    public function block_text($context, array $blocks = [])
    {
        // line 11
        echo "    <div class=\"infotext\">
        <h1>Немного о буклетах</h1>
        <p>
            Основная функция рекламного буклета — информационная и она во многом зависит от рекламного текста.<br>
            Рекламный текст должен быть написан таким образом, чтобы информация о товаре не просто была понятной<br>
            для клиентов, но и отвечала на все возникающие вопросы.
        </p>
        <p>
            Текст должен убедить клиента в том, что ему<br>
            действительно необходимо сотрудничество с вами, но, с другой стороны, как бы хорошо ни был написан<br>
            текст, если цветная печать будет выполнена некачественно, то на него никто не обратит внимание.
        </p>
        <p>
            Поэтому при изготовлении буклетов стоит учитывать, что готовый продукт должен быть ярким,<br>
            запоминающимся, привлекательным и неординарным — это необходимые условия для эффективной «работы» рекламного буклета.
        </p>
        <p>
            Наша компания предлагает изготовление брошюр и буклетов на мелованной матовой или глянцевой бумаге<br>
            любого формата. При необходимости можно заказать буклеты на фактурной дизайнерской бумаге.<br>
            Более подробную информацию можно получить у наших специалистов по телефону.
        </p>
    </div>
    ";
    }

    // line 34
    public function block_form($context, array $blocks = [])
    {
        // line 35
        echo "    <form id=\"feedbackform\" method=\"post\" enctype=\"application/x-www-form-urlencoded\" action=\"\">
        <p>
            <label>Ваш адрес электронной почты
                <input type=\"email\" name=\"eMail\" required>
            </label>
        </p>
        <p>
            <label>Тип бумаги
                <select name=\"papertype\" >
                    <option value=\"\">Глянцевая бумага</option>
                    <option value=\"\">Мелованная бумага</option>
                    <option value=\"\">Матовая бумага</option>
                </select>
            </label>
        </p>
        <p>
            <label>Размер
                <select name=\"size\" >
                    <option value=\"A3\">А3</option>
                    <option value=\"A4\">А4</option>
                    <option value=\"A5\">А5</option>
                </select>
            </label>
        </p>
        <p>
            <label id=\"uploadimg\">Нажмите, чтобы загрузить изображение для печати
                <input id=\"usrimg\" type=\"file\" name=\"userimage\" required>
            </label>
        </p>
        <p>
            <label>Комментарий к заказу
                <textarea name=\"feedbacktext\"></textarea>
            </label>
        </p>
        <p>
            <button id=\"submitbut\">Заказать</button>
        </p>
    </form>
    ";
    }

    public function getTemplateName()
    {
        return "Buklet.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 35,  93 => 34,  67 => 11,  64 => 10,  59 => 8,  53 => 7,  46 => 3,  43 => 2,  33 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "Buklet.html", "/home/david/PhpstormProjects/shabl/templates/Buklet.html");
    }
}
