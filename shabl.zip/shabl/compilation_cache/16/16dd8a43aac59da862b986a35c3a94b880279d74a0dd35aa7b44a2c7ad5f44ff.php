<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* AboutUs.html */
class __TwigTemplate_2fdbda71904efe8236aee0cab716a30681587ecbd6aedb3d4e77f89e2e4fc705 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "AboutUs.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"AboutUs.css\">
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        echo "О нас";
    }

    // line 7
    public function block_sectioninf($context, array $blocks = [])
    {
    }

    // line 9
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 10
        echo "    <div class=\"aboutcompany\">
        <h1 id=\"AboutCompany\">О компании</h1>
        <div class=\"aboutcompanytext\">
            <p>
                <strong>Типография PIX</strong> – современная типография полного цикла. Мы уже много лет занимаемся изготовлением
                полиграфической продукции и уверенно беремся за решение самых сложных и нестандартных задач.
                Индивидуальный подход к каждому клиенту и его целям является основным принципом нашей работы.
            </p>
            <br><br>
            <p>
                Мы предлагаем честное ценообразование и прозрачные условия сотрудничества, поэтому с каждым
                годом все больше заказчиков приходят снова и остаются с нами уже как с постоянными подрядчиками.
            </p>
            <br><br>
            <p>
                К нам обращаются по любым вопросам, связанным с полиграфией – мы получаем более 23 заявок
                каждый день, и делаем все возможное, чтобы превзойти ожидания самого требовательного клиента.
                Качественно выполняя свою работу, мы стремимся построить долгосрочные отношения, основанные на доверии.
            </p>
            <br><br>
            <p>
                Будем рады видеть и вашу компанию в числе наших постоянных клиентов!
            </p>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AboutUs.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 10,  62 => 9,  57 => 7,  51 => 6,  45 => 3,  42 => 2,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "AboutUs.html", "/home/david/PhpstormProjects/shabl/templates/AboutUs.html");
    }
}
