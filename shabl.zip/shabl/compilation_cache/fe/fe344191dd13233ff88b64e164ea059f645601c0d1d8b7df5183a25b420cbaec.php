<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Feedback.html */
class __TwigTemplate_3bd5b51fc65a6a6bf5fd83bfa24f5e53404d996c541fb9977016cb4d9104ac46 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'maincolomn' => [$this, 'block_maincolomn'],
            'text' => [$this, 'block_text'],
            'form' => [$this, 'block_form'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "Feedback.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"Feedback.css\">
";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        echo "Оставить отзыв";
    }

    // line 7
    public function block_sectioninf($context, array $blocks = [])
    {
    }

    // line 9
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 10
        echo "    ";
        $this->displayBlock('text', $context, $blocks);
        // line 24
        echo "        ";
        $this->displayBlock('form', $context, $blocks);
    }

    // line 10
    public function block_text($context, array $blocks = [])
    {
        // line 11
        echo "    <h1>Ваше мнение о предоставленных услугах</h1>
    <div id=\"feedbacktext\">
        <p>
            Мы ценим каждого клиента, и нам<br> очень важно ваше мнение о нас
        </p>
        <p>
            Оцените нашу работу и мы устраним недостатки,<br> а достоинства сделаем еще более явными!
        </p>
        <p>
            Ваша любимая типография PIX.
        </p>
    </div>
    ";
    }

    // line 24
    public function block_form($context, array $blocks = [])
    {
        // line 25
        echo "        <div id=\"formcontainer\">
        <form id=\"feedbackform\" method=\"post\" enctype=\"application/x-www-form-urlencoded\" action=\"\">
            <p>
                <label>Номер вашего заказа
                    <input type=\"number\" name=\"OrderNum\" required>
                </label>
            </p>
            <p>
                <label>Ваш адрес электронной почты
                    <input type=\"email\" name=\"eMail\" required>
                </label>
            </p>
            <fieldset>
                <legend>Оцените качество товара</legend>
                <label>Ужасно
                    <input type=\"radio\" name=\"quality\" value=\"theworst\">
                </label>
                <label>Плохо
                    <input type=\"radio\" name=\"quality\" value=\"bad\">
                </label>
                <label>Нормально
                    <input type=\"radio\" name=\"quality\" value=\"normal\">
                </label>
                <label>Хорошо
                    <input type=\"radio\" name=\"quality\" value=\"good\">
                </label>
                <label>Отлично
                    <input type=\"radio\" name=\"quality\" value=\"thebest\">
                </label>
            </fieldset>
            <p>
                <label>Ваше мнение о товаре
                    <textarea name=\"feedbacktext\"></textarea>
                </label>
            </p>
            <p>
                <button id=\"submitbut\">Отправить отзыв</button>
            </p>
        </form>
    </div>
        ";
    }

    public function getTemplateName()
    {
        return "Feedback.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 25,  94 => 24,  78 => 11,  75 => 10,  70 => 24,  67 => 10,  64 => 9,  59 => 7,  53 => 6,  47 => 3,  44 => 2,  34 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "Feedback.html", "/home/david/PhpstormProjects/shabl/templates/Feedback.html");
    }
}
