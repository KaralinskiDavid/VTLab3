<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* FirstPage.html */
class __TwigTemplate_bf7543ccbcdfa54897038fa96755948e0800294449437a60bb910475bb42e12e extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'maincolomn' => [$this, 'block_maincolomn'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("index.html", "FirstPage.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
";
    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        echo "Типография PIX";
    }

    // line 6
    public function block_sectioninf($context, array $blocks = [])
    {
        // line 7
        echo "    <section class=\"inf_about\">
        <h1>Типография PIX</h1>
        <p>На нашем сайте вы можете ознакомиться с предоставляемыми услугами и оформить заказ на печать</p>
    </section>
";
    }

    // line 12
    public function block_maincolomn($context, array $blocks = [])
    {
        // line 13
        echo "    <a href=\"Buklet.php\"><img id=\"img_buklet\" src=\"files/images/buklet.jpg\"></a>
    <a href=\"Flaer.php\"><img id=\"img_flaery\" src=\"files/images/flaery.jpg\"></a>
    <a href=\"Vizitka.php\"><img id=\"img_vikhitki\" src=\"files/images/vikhitki.jpg\"></a>
";
    }

    public function getTemplateName()
    {
        return "FirstPage.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 13,  67 => 12,  59 => 7,  56 => 6,  50 => 5,  45 => 3,  42 => 2,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "FirstPage.html", "/home/david/PhpstormProjects/shabl/templates/FirstPage.html");
    }
}
