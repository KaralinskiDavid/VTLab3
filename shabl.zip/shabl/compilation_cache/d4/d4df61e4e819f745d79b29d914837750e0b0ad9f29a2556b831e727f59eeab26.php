<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Flaer.html */
class __TwigTemplate_2649ed7b97f3a7cbd45b625a37814c81589d47a34d740734f198d1040eb66217 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'links' => [$this, 'block_links'],
            'title' => [$this, 'block_title'],
            'sectioninf' => [$this, 'block_sectioninf'],
            'text' => [$this, 'block_text'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "Buklet.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("Buklet.html", "Flaer.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_links($context, array $blocks = [])
    {
        // line 3
        echo "    <link rel=\"stylesheet\" href=\"FirstPg.css\">
    <link rel=\"stylesheet\" href=\"Feedback.css\">
    <link rel=\"stylesheet\" href=\"Buklet.css\">
    <link rel=\"stylesheet\" href=\"Flaer.css\">
";
    }

    // line 8
    public function block_title($context, array $blocks = [])
    {
        echo "Флаеры";
    }

    // line 9
    public function block_sectioninf($context, array $blocks = [])
    {
    }

    // line 11
    public function block_text($context, array $blocks = [])
    {
        // line 12
        echo "    <div class=\"infotext\">
        <h1>Немного о флаерах</h1>
        <p>
            Мы печатаем односторонние и двухсторонние флаеры, на матовой и глянцевой бумаге.<br>
            После печати продукция режется в размер, а также при необходимости возможна фальцовка, биговка или перфорация.<br>
            Если у Вас нет готового макета, наши сотрудники сделают дизайн профессионально.
        </p>
        <p>
            Заказывайте печать флаеров в компании «Типография PIX» по отличной цене! Стоимость печати зависит<br>
            от тиража и формата, самые дешевые стандартные размеры — А5, А6 и 100х210 мм.
        </p>
        <p>
            Мы выполним печать флаеров любого вида в соответствии с Вашими интересами, быстро и дешево!<br>
            Возможна доставка продукции в любую точку Минска!
        </p>
        <p>
            Обращайтесь к нам за лучшим результатом!
        </p>
    </div>
    ";
    }

    public function getTemplateName()
    {
        return "Flaer.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 12,  64 => 11,  59 => 9,  53 => 8,  45 => 3,  42 => 2,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "Flaer.html", "/home/david/PhpstormProjects/shabl/templates/Flaer.html");
    }
}
